﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToDoDashboard.Application.DTO
{
    public class CreateUserDTO
    {
        [Required(AllowEmptyStrings = false)]
        public string Name { get; set; }
        [Required(AllowEmptyStrings = false)]
        [EmailAddress]
        public string? EmailId { get; set; }
        public string Password { get; set; }
        [Required(AllowEmptyStrings = false)]
        [Phone]
        public string ContactNumber { get; set; }
    }
}

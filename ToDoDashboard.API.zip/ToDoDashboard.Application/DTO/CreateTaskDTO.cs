﻿using System.ComponentModel.DataAnnotations;
using ToDoDashboard.Domain.Enum;

namespace ToDoDashboard.Application.DTO
{
    public class CreateTaskDTO
    {
        [Required]
        [StringLength(100)]
        public string Title { get; set; }
        [Required]
        [StringLength(400)]
        public string Description { get; set; }
        [Required]
        public Priority Priority { get; set; }
        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Due Date")]
        public DateTime DueDate { get; set; }
        [Required]
        public Status Status { get; set; }
        [Required]
        public int CreatedBy { get; set; }
    }
}

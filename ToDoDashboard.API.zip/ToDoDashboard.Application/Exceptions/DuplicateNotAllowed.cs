﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToDoDashboard.Application.Exceptions
{
    public class DuplicateNotAllowed :Exception
    {
        public DuplicateNotAllowed() : base() { }
        public DuplicateNotAllowed(string message) : base(message) { }
    }
}

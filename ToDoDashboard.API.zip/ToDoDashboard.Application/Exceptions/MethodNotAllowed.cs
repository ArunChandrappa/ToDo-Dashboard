﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToDoDashboard.Application.Exceptions
{
    public class MethodNotAllowed : Exception
    {
        public MethodNotAllowed() : base() { }
        public MethodNotAllowed(string message) : base(message) { }
    }
}

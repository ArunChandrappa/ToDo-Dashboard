﻿using ToDoDashboard.Application.DTO;

namespace ToDoDashboard.Application.Services.Interfaces
{
    public interface ITaskServices
    {
        Task<IEnumerable<TaskDTO>> GetAllTasks();
        public Task<IEnumerable<TaskViewModel>> GetTaskByUserId(int userId);
        public Task<string> CreateTask(CreateTaskDTO createTask);
        public Task<int> UpdateTask(TaskUpdateDTO updateTask);
        public Task<string> DeleteTask(int id);
    }
}

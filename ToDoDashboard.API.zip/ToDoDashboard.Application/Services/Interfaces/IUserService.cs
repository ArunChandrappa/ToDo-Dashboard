﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ToDoDashboard.Application.DTO;
using ToDoDashboard.Domain.Entities;

namespace ToDoDashboard.Application.Services.Interfaces
{
    public interface IUserService
    {
        public Task<UserDTO> GetUserById(int id);
        public Task<string> CreateUser(CreateUserDTO createUser);
        public Task<string> DeleteUser(int id);
        public Task<User> GetUserByEmailId(string emailId);
    }
}

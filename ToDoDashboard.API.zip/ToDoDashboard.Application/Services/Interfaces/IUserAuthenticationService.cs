﻿using ToDoDashboard.Application.DTO;

namespace ToDoDashboard.Application.Services.Interfaces
{
    public interface IUserAuthenticationService
    {
        public Task<int> UserAuthentication(UserAuthenticationDTO userlogin);
    }
}

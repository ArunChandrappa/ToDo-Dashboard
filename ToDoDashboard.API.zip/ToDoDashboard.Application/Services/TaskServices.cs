﻿using AutoMapper;
using ToDoDashboard.Application.DTO;
using ToDoDashboard.Application.Services.Interfaces;
using ToDoDashboard.Infrastructure.Repositories.Interfaces;

namespace ToDoDashboard.Application.Services
{
    public class TaskServices : ITaskServices
    {
        private readonly ITaskRepository _taskRepository;
        private readonly IMapper _mapper;
        public TaskServices(ITaskRepository taskRepository, IMapper mapper)
        {
            _taskRepository = taskRepository;
            _mapper = mapper;
        }
        public async Task<IEnumerable<TaskDTO>> GetAllTasks()
        {
            var tasks = await _taskRepository.GetAllTasks();
            var response = _mapper.Map<List<TaskDTO>>(tasks);
            return response;
        }
        public async Task<int> UpdateTask(TaskUpdateDTO updateTask)
        {

            var task = await _taskRepository.GetByTaskId(updateTask.Id);

            if (task != null)
            {
                var result = _mapper.Map<Domain.Entities.Task>(updateTask);
                await _taskRepository.UpdateTask(result);
                return (updateTask.Id);
            }
            else
            {
                throw new KeyNotFoundException($"Task Id: {updateTask.Id} does not exist");
            }
        }
        public async Task<string> CreateTask(CreateTaskDTO createTask)
        {
            var taskData = _mapper.Map<Domain.Entities.Task>(createTask);
            taskData.CreatedDate = DateTime.UtcNow;
            await _taskRepository.AddTask(taskData);
            return ($"Task {taskData.Title} Created Successfully");
        }
        public async Task<IEnumerable<TaskViewModel>> GetTaskByUserId(int userId)
        {
            var tasks = await _taskRepository.GetTaskByUserId(userId);
            var taskView = from task in tasks
                           select new TaskViewModel()
                           {
                               Id = task.Id,
                               Title = task.Title,
                               Priority = task.Priority.ToString(),
                               Status = task.Status.ToString(),
                               Description = task.Description,
                               DueDate = task.DueDate,
                               CreatedDate = task.CreatedDate,
                           };
            if (taskView != null)
            {
                return taskView;
            }
            throw new KeyNotFoundException($"user Id: {userId} does not exist");
        }
        public async Task<string> DeleteTask(int id)
        {
            var isDeleted = await _taskRepository.DeleteTask(id);
            if (isDeleted)
                return ($"Task Id: {id} successfully deleted");
            else
                throw new KeyNotFoundException($"Task Id: {id} does not exist");
        }
    }
}


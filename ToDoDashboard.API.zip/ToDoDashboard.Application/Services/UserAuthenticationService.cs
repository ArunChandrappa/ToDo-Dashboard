﻿using ToDoDashboard.Application.DTO;
using ToDoDashboard.Application.Services.Interfaces;

namespace ToDoDashboard.Application.Services
{
    public class UserAuthenticationService : IUserAuthenticationService
    {
        private readonly IUserService _userService;
        public UserAuthenticationService(IUserService userService)
        {
            _userService = userService;
        }
        public async Task<int> UserAuthentication(UserAuthenticationDTO userlogin)
        {

            var user = await _userService.GetUserByEmailId(userlogin.EmailId);
            if (user != null)
            {
                var isVerified = BCrypt.Net.BCrypt.Verify(userlogin.Password, user.Password);
                if (isVerified)
                {
                    return user.Id;
                }
            }
            throw new UnauthorizedAccessException("unauthorized");
        }
    }
}

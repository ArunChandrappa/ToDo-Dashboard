﻿
using AutoMapper;
using ToDoDashboard.Application.DTO;
using ToDoDashboard.Application.Exceptions;
using ToDoDashboard.Application.Services.Interfaces;
using ToDoDashboard.Domain.Entities;
using ToDoDashboard.Infrastructure.Repositories.Interfaces;

namespace ToDoDashboard.Application.Services
{
    public class UserServices : IUserService
    {
        private readonly IUserRepository _userRepository;
        private readonly IMapper _mapper;
        public UserServices(IUserRepository userRepository, IMapper mapper)
        {
            _userRepository = userRepository;
            _mapper = mapper;
        }
        public async Task<string> CreateUser(CreateUserDTO createUser)
        {
            var existingUser = _userRepository.GetQuery().Where(e => e.EmailId == createUser.EmailId).FirstOrDefault();
            if (existingUser == null)
            {
                var userData = _mapper.Map<User>(createUser);
                userData.Password = BCrypt.Net.BCrypt.HashPassword(createUser.Password);
                await _userRepository.AddUser(userData);
                return $"User {userData.Name} added Succesfully";

            }
            else
            {
                throw new DuplicateNotAllowed("User already exist, please login");
            }
        }

        public async Task<string> DeleteUser(int id)
        {
            var (isDeleted, userName) = await _userRepository.DeleteUser(id);
            if (isDeleted)
                return ($"User {userName} deleted Successfully");
            else
                throw new KeyNotFoundException($"User Id: {id} does not exist");
        }

        public async Task<UserDTO> GetUserById(int id)
        {
            var result = await _userRepository.GetUserById(id);
            if (result == null)
            {
                throw new KeyNotFoundException($"User Id: {id} does not exist");
            }
            var response = _mapper.Map<UserDTO>(result);
            return response;
        }
        public async Task<User> GetUserByEmailId(string emailId)
        {
            var result = await _userRepository.GetUserByEmailId(emailId);
            if (result == null)
            {
                throw new KeyNotFoundException("EmailId does not exist");
            }
            return result;

        }
    }
}
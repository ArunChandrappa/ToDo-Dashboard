﻿namespace ToDoDashboard.Domain.Enum
{
    public enum Status
    {
        New,
        InProgress,
        Hold,
        Completed,
        Removed,
        OverDue
    }
}

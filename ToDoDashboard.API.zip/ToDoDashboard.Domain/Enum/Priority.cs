﻿namespace ToDoDashboard.Domain.Enum
{
    public enum Priority
    {
        Urgent,
        High,
        Medium,
        Low
    }
}

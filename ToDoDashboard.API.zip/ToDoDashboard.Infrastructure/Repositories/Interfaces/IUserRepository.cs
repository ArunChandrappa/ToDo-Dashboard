﻿using ToDoDashboard.Domain.Entities;

namespace ToDoDashboard.Infrastructure.Repositories.Interfaces
{
    public interface IUserRepository
    {
        public Task<User> GetUserById(int id);
        public Task<int> AddUser(User user);
        public Task<(bool, string)> DeleteUser(int id);
        public Task<int> Save();
        public IQueryable<User> GetQuery();
        public Task<User> GetUserByEmailId(string emailId);
    }
}

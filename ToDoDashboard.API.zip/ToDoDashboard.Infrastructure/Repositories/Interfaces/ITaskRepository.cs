﻿namespace ToDoDashboard.Infrastructure.Repositories.Interfaces
{
    public interface ITaskRepository
    {
        public Task<IEnumerable<Domain.Entities.Task>> GetAllTasks();
        public Task<IEnumerable<Domain.Entities.Task>>GetTaskByUserId(int userId);
        public Task<Domain.Entities.Task> GetByTaskId(int id);
        public Task<int> AddTask(Domain.Entities.Task task);
        public Task<Domain.Entities.Task> UpdateTask(Domain.Entities.Task task);
        public Task<bool> DeleteTask(int id);
        public Task<int> Save();

    }
}

﻿using Microsoft.EntityFrameworkCore;
using ToDoDashboard.Domain.Entities;
using ToDoDashboard.Infrastructure.Repositories.Interfaces;

namespace ToDoDashboard.Infrastructure.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly ToDoDashboardDbContext dBContext;
        public UserRepository(ToDoDashboardDbContext dBContext)
        {
            this.dBContext = dBContext;
        }
        public async Task<int> AddUser(User user)
        {
            await dBContext.User.AddAsync(user);
            await Save();
            return user.Id;
        }

        public async Task<(bool,string)> DeleteUser(int id)
        {
            var user = await GetUserById(id);
            if (user != null)
            {
                dBContext.User.Remove(user);
                await Save();
                return (true,user.Name);
            }
            return (false,string.Empty);
        }

        public async Task<User> GetUserById(int id)
        {
            return await dBContext.User.FirstOrDefaultAsync(x => x.Id == id);
        }
        public async Task<User> GetUserByEmailId(string emailId)
        {
            return await dBContext.User.FirstOrDefaultAsync(x => x.EmailId == emailId);

        }
        public IQueryable<User> GetQuery()
        {
            return dBContext.User;
        }
        public async Task<int> Save()
        {
            return await dBContext.SaveChangesAsync();
        }
    }

}

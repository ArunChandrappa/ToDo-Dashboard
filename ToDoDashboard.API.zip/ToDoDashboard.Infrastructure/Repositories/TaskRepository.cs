﻿using Microsoft.EntityFrameworkCore;
using ToDoDashboard.Infrastructure.Repositories.Interfaces;

namespace ToDoDashboard.Infrastructure.Repositories
{
    public class TaskRepository : ITaskRepository
    {
        private readonly ToDoDashboardDbContext dBContext;

        public TaskRepository(ToDoDashboardDbContext dBContext)
        {
            this.dBContext = dBContext;
        }

        public async Task<int> AddTask(Domain.Entities.Task task)
        {
            await dBContext.Task.AddAsync(task);
            await Save();
            return task.Id;
        }
        public async Task<IEnumerable<Domain.Entities.Task>> GetTaskByUserId(int userId)
        {
            return await dBContext.Task.Where(x => x.CreatedBy == userId).OrderBy(x=>x.DueDate).ToListAsync();
        }

        public async Task<bool> DeleteTask(int id)
        {
            var task = await GetByTaskId(id);
            if (task != null)
            {
                dBContext.Task.Remove(task);
                await Save();
                return true;
            }
            return false;
        }

        public async Task<IEnumerable<Domain.Entities.Task>> GetAllTasks()
        {
            return await dBContext.Task.ToListAsync();
        }

        public async Task<Domain.Entities.Task> GetByTaskId(int id)
        {
            return await dBContext.Task.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);

        }

        public async Task<int> Save()
        {
            return await dBContext.SaveChangesAsync();
        }

        public async Task<Domain.Entities.Task> UpdateTask(Domain.Entities.Task task)
        {
            dBContext.Task.Update(task);
            await Save();
            return task;
        }
    }
}

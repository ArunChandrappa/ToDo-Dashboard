﻿using Microsoft.EntityFrameworkCore;
using System.Reflection;
using ToDoDashboard.Domain.Entities;

namespace ToDoDashboard.Infrastructure
{
    public class ToDoDashboardDbContext : DbContext
    {
        public DbSet<User> User { get; private set; }
        public DbSet<Domain.Entities.Task> Task { get; private set; }

        public ToDoDashboardDbContext(DbContextOptions<ToDoDashboardDbContext> contextOptions) : base(contextOptions)
        { }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());

        }
    }
}

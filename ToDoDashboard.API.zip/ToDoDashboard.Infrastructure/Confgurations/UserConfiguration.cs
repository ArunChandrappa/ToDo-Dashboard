﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ToDoDashboard.Domain.Entities;

namespace ToDoDashboard.Infrastructure.Confgurations
{
    public class UserConfiguration : IEntityTypeConfiguration<User>
    {
        public void Configure(EntityTypeBuilder<User> builder)
        {
            builder.HasKey(ur => ur.Id);

            builder.Property(p => p.Name).IsRequired().HasMaxLength(50);
            builder.Property(p => p.EmailId).IsRequired();
            builder.Property(p => p.Password).IsRequired();
            builder.Property(p => p.ContactNumber).IsRequired().HasMaxLength(10);

            builder.HasMany(u => u.Tasks)
                .WithOne(u => u.User)
                .HasForeignKey(u => u.CreatedBy);
        }
    }
}

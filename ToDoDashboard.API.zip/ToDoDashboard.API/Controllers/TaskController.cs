﻿using Microsoft.AspNetCore.Mvc;
using ToDoDashboard.Application.DTO;
using ToDoDashboard.Application.Services.Interfaces;

namespace ToDoDashboard.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TaskController : ControllerBase
    {
        private readonly ITaskServices taskServices;
        public TaskController(ITaskServices taskServices)
        {
            this.taskServices = taskServices;
        }
        [HttpPost]
        public async Task<IActionResult> CreateTask(CreateTaskDTO createTaskDTO)
        {
            var result = await taskServices.CreateTask(createTaskDTO);
            return StatusCode(201, result); ;
        }
        [HttpPut]
        public async Task<IActionResult> UpdateTask(TaskUpdateDTO updateTask)
        {
            var result = await taskServices.UpdateTask(updateTask);
            return Ok(result);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTask(int id)
        {
            if (id <= 0)
            {
                throw new ArgumentOutOfRangeException($"Invalid Id : {id}");
            }
            var response = await taskServices.DeleteTask(id);
            return StatusCode(200, response);
        }
        [HttpGet]
        public async Task<IActionResult> GetTask()
        {
            var result = await taskServices.GetAllTasks();
            return Ok(result);
        }
        [HttpGet("{UserId}")]
        public async Task<IActionResult> GetTaskByUserId(int UserId)
        {
            if (UserId <= 0)
            {
                throw new ArgumentOutOfRangeException($"Invalid Id : {UserId}");
            }
            var result = await taskServices.GetTaskByUserId(UserId);
            return Ok(result);
        }
    }
}

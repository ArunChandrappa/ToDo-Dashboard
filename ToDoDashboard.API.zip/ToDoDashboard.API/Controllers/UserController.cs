﻿using Microsoft.AspNetCore.Mvc;
using ToDoDashboard.Application.DTO;
using ToDoDashboard.Application.Services.Interfaces;

namespace ToDoDashboard.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService userService;
        public UserController(IUserService userService)
        {
            this.userService = userService;
        }
        [HttpPost]
        public async Task<IActionResult> CreateUser(CreateUserDTO createUser)
        {
            var result = await userService.CreateUser(createUser);
            return StatusCode(201, result);
        }
        [HttpGet]
        public async Task<IActionResult> GetUserById(int id)
        {
            if (id <= 0)
            {
                throw new ArgumentOutOfRangeException($"Invalid Id : {id}");
            }
            var result = await userService.GetUserById(id);
            return Ok(result);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            if (id <= 0)
            {
                throw new ArgumentOutOfRangeException($"Invalid Id : {id}");
            }
            var response = await userService.DeleteUser(id);
            return StatusCode(200, response);
        }
    }
}

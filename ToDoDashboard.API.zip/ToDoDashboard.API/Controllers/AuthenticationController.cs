﻿using Microsoft.AspNetCore.Mvc;
using ToDoDashboard.Application.DTO;
using ToDoDashboard.Application.Services.Interfaces;

namespace ToDoDashboard.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private readonly IUserAuthenticationService userAuthenticationService;
        public AuthenticationController(IUserAuthenticationService userAuthenticationService)
        {
            this.userAuthenticationService = userAuthenticationService;
        }
        [HttpPost]
        public async Task<IActionResult> UserAuthentication([FromBody] UserAuthenticationDTO userlogin)
        {
            var userId = await userAuthenticationService.UserAuthentication(userlogin);
            if (userId <= 0)
            {
                return StatusCode(401, "unauthorized");
            }
            return Ok(userId);
        }
    }
}

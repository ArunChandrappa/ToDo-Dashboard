﻿using AutoMapper;
using ToDoDashboard.Application.DTO;
using ToDoDashboard.Domain.Entities;

namespace ToDoDashboard.API.AutoMapper_Profile
{
    public class Mapper :Profile
    {
        public Mapper()
        {
            CreateMap<CreateTaskDTO, Domain.Entities.Task>().ReverseMap();
            CreateMap<TaskDTO, Domain.Entities.Task>().ReverseMap();
            CreateMap<TaskUpdateDTO, Domain.Entities.Task>().ReverseMap();
            CreateMap<UserAuthenticationDTO, User>().ReverseMap();
            CreateMap<CreateUserDTO, User>().ReverseMap();
            CreateMap<User, UserDTO>().ReverseMap();
        }
    }
}

import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { EmailValidator, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TodoDashboardServiceService } from 'src/Services/User.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  formGroup: FormGroup;
  constructor(private authservice: TodoDashboardServiceService, private formBuilder: FormBuilder, private router: Router) {
    this.formGroup = this.formBuilder.group({
      emailId: ['',[Validators.required, Validators.email,Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      password: ['', Validators.required],
    })
  }

  ngOnInit(): void {
    this.formGroup.valueChanges.subscribe(value => {
      console.log(value);
    })
  }

  login() {
    this.authservice.login(this.formGroup.value).subscribe({
      next: (response) => {
        console.log(response.body);
        localStorage.setItem('userId', response.body);
        this.formGroup.reset();
        this.router.navigate(['TodoDashboard'])
      }
      ,
      error(error: HttpErrorResponse) {
        if (error.status == 401) {
          alert('password incorrect')
        }
        else if (error.status == 404) {
          alert('Email Id Not Found')
        }
        else {
          console.log('something went wrong')
        }
      }

    })
  }
}


import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { TodoDashboardServiceService } from 'src/Services/User.service';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {
  Signupform: FormGroup;
  constructor(private authservice: TodoDashboardServiceService, private formBuilder: FormBuilder, private router: Router) {
    this.Signupform = this.formBuilder.group({
      name: ['', [Validators.required, Validators.maxLength(15), Validators.minLength(3)],],
      emailId: ['', [Validators.required, Validators.email, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      password: ['', Validators.required],
      contactNumber: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10),]]

    })

  }
  signup() {
    this.authservice.signup(this.Signupform.value).subscribe({
      next: (value) => {
        Swal.fire({
          icon: 'success',
          title: 'Welcome to ToDo Dashboard',
          text: 'SignUp Successful, Please login',
        }).then(() => {
          this.Signupform.reset();
          this.router.navigate(["/login"])
        })
      }
      ,
      error(error: HttpErrorResponse) {
        if (error.status == 409) {
          Swal.fire({
            icon: 'error',
            title: 'Oops...Conflict',
            text: 'User already exist, please login',
          });
          console.log('Conflict');
        }
        if(error.status == 400){
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Bad Request, please Give valid Data',
          });
        }

      }

    })
  }

}
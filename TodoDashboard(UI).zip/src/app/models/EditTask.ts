export class EditTask {
    public id: number;
    public title: string;
    public description: string;
    public priority: number;
    public dueDate: string;
    public status: number;
    public createdBy: number;

    constructor(id: number, title: string, description: string, priority: string, dueDate: string, status: string, createdBy: string) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.priority = Number(priority);
        this.dueDate = dueDate;
        this.status = Number(status);
        this.createdBy = Number(createdBy);

    }

}
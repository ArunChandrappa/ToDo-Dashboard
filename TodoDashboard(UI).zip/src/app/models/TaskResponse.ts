export class TaskResponse {
    public title: string;
    public description: string;
    public priority: string;
    public dueDate: string;
    public status: string;

    constructor(title: string, description: string, priority: string, dueDate: string, status: string) {
        this.title = title;
        this.description = description;
        this.priority = priority;
        this.dueDate = dueDate;
        this.status = status;

    }

}
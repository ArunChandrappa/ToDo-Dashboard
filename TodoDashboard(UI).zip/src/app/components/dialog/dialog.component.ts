import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {MAT_DIALOG_DATA } from '@angular/material/dialog';
import { EditTask } from 'src/app/models/EditTask';
import { TaskService } from 'src/Services/task.service';
import Swal from 'sweetalert2';
import { TaskRequest } from '../../models/TaskRequest';

@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.css']
})
export class DialogComponent implements OnInit {
  formTitle: string = 'Create Task';
  actionButton: string = 'Create Task';
  buttonAction: string = 'Create';
  taskForm !: FormGroup;
  taskResponse: any;
  title: string = '';
  description: string = '';
  priority: number = 0;
  dueDate: string = '';
  status: number = 0;
  createdBy: any;
  constructor(private service: TaskService,
    private formBuilder: FormBuilder,
    private taskservice: TaskService,
    @Inject(MAT_DIALOG_DATA) private task: EditTask) { }

  ngOnInit(): void {
    if (this.task != null) {
      this.formTitle = 'Edit Task';
      this.actionButton = 'Edit Task';
      this.buttonAction = 'Edit';
      this.title = this.task.title;
      this.description = this.task.description;
      this.priority = Number(this.task.priority);
      this.status = this.task.status;
      this.dueDate = this.task.dueDate;
      console.log(this.task);
    };
    this.taskForm = this.formBuilder.group({
      title: [this.title,  [
        Validators.required,
        Validators.pattern(/^[a-zA-Z ]*$/),
        Validators.maxLength(21),
        Validators.minLength(4),
      ],],
      description: [this.description,  [
        Validators.required,
        Validators.maxLength(50),
        Validators.minLength(10),
      ],],
      priority: [this.priority,[ Validators.required]],
      status: [this.status, [Validators.required]],
      dueDate: [this.dueDate, [Validators.required]],
    })
  }
  statusTypeList: statusType[] = [
    new statusType(0, "New"),
    new statusType(1, "InProgress"),
    new statusType(2, "Hold"),
    new statusType(3, "Completed"),
    new statusType(4, "Removed"),
    new statusType(5, "OverDue"),

  ]
  priorityList: priorityType[] = [
    new priorityType(0, "Urgent"),
    new priorityType(1, "High"),
    new priorityType(2, "Medium"),
    new priorityType(3, "Low"),

  ]

  addTask(value: string) {
    let userId = localStorage.getItem('userId') ?? "";
    if (value == 'Create') {
      const task = new TaskRequest(
        this.taskForm.value.title,
        this.taskForm.value.description,
        this.taskForm.value.priority,
        this.taskForm.value.dueDate,
        this.taskForm.value.status,
        userId
      );
      console.log(task)
      this.taskservice.addtask(task).subscribe({
        next: () => {
          Swal.fire({
            icon: 'success',
            title: 'Added Task',
            text: 'Task Added Successfully',
          }).then(() => {
            window.location.reload();
          });
        },
        error() {
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Something went wrong! Please try again',
          });
        },
      });
    }
    else {
      const task = new EditTask(
        this.task?.id,
        this.taskForm.value.title,
        this.taskForm.value.description,
        this.taskForm.value.priority,
        this.taskForm.value.dueDate,
        this.taskForm.value.status,
        userId,
      );
      console.log(task)
      this.taskservice.editTask(task).subscribe({
        next: (data) => {
          console.log(data),
          Swal.fire({
            icon: 'success',
            title: 'Update Task',
            text: 'Task Updated Successfully',
          }).then(() => {
            window.location.reload();
          });
        },
        error() {
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Something went wrong! Please try again',
          });
        },
      });
    }

  }

}
export class statusType {
  id: Number;
  name: string;

  constructor(id: Number, name: string) {
    this.id = id;
    this.name = name;
  }

}
export class priorityType {
  id: Number;
  name: string;

  constructor(id: Number, name: string) {
    this.id = id;
    this.name = name;
  }

}

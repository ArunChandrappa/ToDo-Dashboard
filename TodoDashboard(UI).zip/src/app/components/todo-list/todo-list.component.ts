import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { getTask } from 'src/app/models/getTask';
import { TaskService } from 'src/Services/task.service';
import Swal from 'sweetalert2';
import { DialogComponent } from '../dialog/dialog.component';

@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.css']
})
export class TodoListComponent implements OnInit {
  @Input() data?: getTask[];
  constructor(private task: FormBuilder, private router: Router, private dialog: MatDialog, private service: TaskService) {
  }
  editTask(task: getTask) {
    let userId = localStorage.getItem('userId') ?? "";
    this.dialog.open(DialogComponent, {
      data: {
        id: task.id,
        title: task.title,
        description: task.description,
        priority: Number(task.priority),
        dueDate: task.dueDate,
        status: task.status,
        userId
      },
      width: '30%',
    })
  }
  deleteTask(task: getTask) {
    this.service.deleteTask(task.id).subscribe({
      next: (response) => {
        console.log(response.body);
        Swal.fire('Deleted!', 'Your task has been deleted.', 'success');
      }
    })
  }
  ngOnInit(): void {
  }
}

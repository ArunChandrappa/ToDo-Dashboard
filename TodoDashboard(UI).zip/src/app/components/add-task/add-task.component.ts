import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { TaskService } from 'src/Services/task.service';
import { EditTask } from 'src/app/models/EditTask';
import { DialogComponent } from '../dialog/dialog.component';
import { getTask } from 'src/app/models/getTask';
@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css']
})
export class AddTaskComponent implements OnInit {
  public New: getTask[] = [];
  public InProgress: getTask[] = [];
  public Completed: getTask[] = [];
  public Blocked: getTask[] = [];
  public OverDue: getTask[] = [];
  public Removed: getTask[] = [];
  public Hold: getTask[] = [];
  constructor(private dialog: MatDialog, private service: TaskService,) { }
  todolists: any;
  openDialog(): void {
    this.dialog.open(DialogComponent, {
      width: '30%'
    });
  }
  ngOnInit(): void {
    this.getallTasks();
  }
  getallTasks() {

    let userId = Number(localStorage.getItem('userId'));
    this.service.getTaskByUserId(userId).subscribe(data => {
      console.log(data);
      for (let task of data) {
        let isOverDue = Date.parse(task.dueDate) < Date.now();
        if (!isOverDue && task.status == "New") this.New.push(new getTask(task.id, task.title, task.description, task.priority, task.dueDate, task.status, task.userId));
        if (!isOverDue && task.status == "InProgress") this.InProgress.push(new getTask(task.id, task.title, task.description, task.priority, task.dueDate, task.status, task.userId));
        if (!isOverDue && task.status == "Hold") this.Hold.push(new getTask(task.id, task.title, task.description, task.priority, task.dueDate, task.status, task.userId));
        if (task.status == "Completed") this.Completed.push(new getTask(task.id, task.title, task.description, task.priority, task.dueDate, task.status, task.userId));
        if (task.status == "Removed") this.Removed.push(new getTask(task.id, task.title, task.description, task.priority, task.dueDate, task.status, task.userId));
        if (isOverDue) this.OverDue.push(new getTask(task.id, task.title, task.description, task.priority, task.dueDate, task.status, task.userId));
      }
    },
    )
    console.log(this.New);
  }
}

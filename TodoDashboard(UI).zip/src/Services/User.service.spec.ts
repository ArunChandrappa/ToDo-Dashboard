import { TestBed } from '@angular/core/testing';

import { TodoDashboardServiceService } from './User.service';

describe('TodoDashboardServiceService', () => {
  let service: TodoDashboardServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TodoDashboardServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
